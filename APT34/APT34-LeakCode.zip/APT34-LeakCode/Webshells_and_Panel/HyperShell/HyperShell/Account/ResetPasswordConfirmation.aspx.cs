﻿using System.Web.UI;

namespace HyperShell.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}