### BlackBasta Chat Logs

[![](https://i.ibb.co/qMkHWfTK/698yt9.png)](https://i.ibb.co/qMkHWfTK/698yt9.png)

Since absolutely nobody has posted this in more publicly accessible places for whatever reason that may be, I've decided to upload them here. The dates of the leaked data range from September 18th, 2023 to September 28th, 2024. There is 196,045 messages. All of which are in Russian. I don't have the time nor the care to translate. However several other's have.

The leak was initally discovered by: PRODAFT
Confirmed by VXUnderground 
Native Russian Speakers whom helped out with the investigation as per VXUG's Shoutouts are: @ddd1ms, @RussianPanda9xx and @exception805 (All on X. Please, follow these lovely people if you haven't.)
